-- AlterTable
ALTER TABLE "Ride" ADD COLUMN     "feedback" TEXT,
ADD COLUMN     "rating" INTEGER;
