-- AlterEnum
ALTER TYPE "RideStatus" ADD VALUE 'IN_PROGRESS';
